

from django.shortcuts import render, redirect
import django.contrib.auth.views as auth_view
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render
from e_invoices.models import RegisterForm
from e_invoices.models import LoginForm
from e_invoices.models import Invoice
from django.db.models import Count
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
import xml.etree.ElementTree as ET
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from django.shortcuts import get_object_or_404
from django.http import HttpResponse
from django.http import JsonResponse
from e_invoices.models import Sapfagll03
from e_invoices.models import Myinvoiceportal 
from django.db import connection
from e_invoices.models import Twa0101
from e_invoices.models import Twa0101Item
from e_invoices.models import Ocritem
from e_invoices.models import Ocr
import pandas as pd
from django.http import HttpResponse
from django.shortcuts import get_list_or_404
from django.shortcuts import render
from django.http import JsonResponse
import subprocess
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Q
from e_invoices.models import Company
from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from e_invoices.models import UserProfile, Company
from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_exempt
import json
import os
from io import BytesIO
from django.conf import settings
from openpyxl import load_workbook
import logging
from datetime import datetime, timedelta
from django.db.models import Q
from django.core.paginator import Paginator
from django.contrib import messages
from e_invoices.models import NumberDistribution
from django.utils import timezone
from collections import defaultdict
from django.db import transaction
from django.forms import modelform_factory
from e_invoices.forms import NumberDistributionForm
from e_invoices.models import TWB2BMainItem
from e_invoices.models import TWB2BLineItem


@csrf_exempt
def upload_file_tw(request):
    if request.method == "POST":
        uploaded_file = request.FILES.get("invoice_file")

        if not uploaded_file:
            return JsonResponse({"success": False, "error": "沒有收到檔案"}, status=400)

        os.makedirs(UPLOAD_DIR_TW, exist_ok=True)
        file_path = os.path.join(UPLOAD_DIR_TW, uploaded_file.name)

        try:
            with open(file_path, "wb") as f:
                for chunk in uploaded_file.chunks():
                    f.write(chunk)

            return JsonResponse({"success": True, "file_path": file_path})
        except Exception as e:
            return JsonResponse({"success": False, "error": str(e)}, status=500)

    return JsonResponse({"success": False, "error": "無效的請求"}, status=400)

@csrf_exempt
def run_script_tw(request):
    """Execute the parse.py script which handles Excel to DB import."""
    parse_script_path = os.path.join(UPLOAD_DIR_TW, "import2sqlite.py")
    
    if request.method == "POST":
        try:
            # 執行 parse.py 腳本（Python 版本依實際情況調整：python 或 python3）
            script_output = subprocess.check_output(["python", parse_script_path], text=True)

            return JsonResponse({"success": True, "output": script_output})

        except subprocess.CalledProcessError as e:
            return JsonResponse({"success": False, "error": str(e.output)}, status=500)

    return JsonResponse({"success": False, "error": "Invalid request"}, status=400)
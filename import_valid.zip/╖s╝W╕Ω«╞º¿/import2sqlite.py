import os
import sqlite3
import pandas as pd
import glob

# Path to the folder containing Excel files
downloads_folder = os.path.expanduser("C:/Users/waylin/mydjango/e_invoice/upload")
# Get all .xlsx files in the folder
excel_files = glob.glob(os.path.join(downloads_folder, "*.xlsx"))

# Insert data into a specific table in SQLite database
def insert_data_to_table(parsed_result, table_name, connection):
    """
    將解析後的資料插入指定的 SQLite 資料表中
    :param parsed_result: 要插入的資料，應為列表格式
    :param table_name: 要插入資料的資料表名稱
    :param connection: SQLite 資料庫的連接物件
    """
    # 使用 cursor 來執行資料庫操作
    with connection.cursor() as cursor:
        # 根據 table_name 判斷插入的資料表
        if table_name == "table_a":
            # 如果資料表是 table_a，執行對應的 INSERT 語句
            cursor.execute("""
                INSERT INTO table_a (submissionUid, longId, internalId, typeName, typeVersionName)
                VALUES (?, ?, ?, ?, ?)
            """, (
                parsed_result["submissionUid"], parsed_result["longId"],
                parsed_result["internalId"], parsed_result["typeName"],
                parsed_result["typeVersionName"]
            ))
        elif table_name == "table_b":
            # 如果資料表是 table_b，執行對應的 INSERT 語句，並處理 errorReason 欄位
            cursor.execute("""
                INSERT INTO table_b (submissionUid, longId, internalId, typeName, typeVersionName, errorReason)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                parsed_result["submissionUid"], parsed_result["longId"],
                parsed_result["internalId"], parsed_result["typeName"],
                parsed_result["typeVersionName"], parsed_result.get("errorReason", "")
            ))
        # 提交變更，將資料寫入資料庫
        connection.commit()

# 驗證和處理 Excel 資料
def validate_and_process(df):
    """
    驗證 Excel 資料並處理有效與無效資料
    :param df: 從 Excel 讀取的 DataFrame
    :return: valid_data (有效資料), invalid_data (無效資料)
    """
    valid_data = []  # 儲存符合條件的有效資料
    invalid_data = []  # 儲存不符合條件的無效資料

    # 逐列檢查資料
    for index, row in df.iterrows():
        # 如果 ERP_number 為 1，視為有效資料
        if row['ERP_number'] == 1:
            valid_data.append(row)
        else:
            # 否則視為無效資料
            invalid_data.append(row)

    # 對有效資料進行分組與合併
    if valid_data:
        # 將有效資料轉換成 DataFrame 格式
        valid_df = pd.DataFrame(valid_data)
        
        # 根據 ERP_number 進行分組，並彙總需要的欄位
        grouped_df = valid_df.groupby("ERP_number", as_index=False).agg({
            "ERP_year": "first",  # 取得第一個 ERP_year 值
            "ERP_date": "first",  # 取得第一個 ERP_date 值
            "ERP_reference": "first",  # 取得第一個 ERP_reference 值
            "invoice_period": "sum",  # 計算 invoice_period 欄位的總和
            "seller_tax_id": "first",  # 取得第一個 seller_tax_id 值
            "seller_bp_id": "first",  # 取得第一個 seller_bp_id 值
            "buyer_tax_id": "first",  # 取得第一個 buyer_tax_id 值
            "buyer_name": "first"  # 取得第一個 buyer_name 值
        })

        # 將處理後的資料轉換為列表格式，準備插入資料庫
        valid_parsed_result = grouped_df[["ERP_number", "ERP_year", "ERP_date", "ERP_reference", "invoice_period",
                                          "seller_tax_id", "seller_bp_id", "buyer_tax_id", "buyer_name"]].values.tolist()
        
        # 根據 ERP_number 判斷要將資料插入的資料表
        for row in valid_parsed_result:
            if row[0] == 1:
                table_name = "A"  # 如果 ERP_number 為 1，插入到資料表 A
            elif row[0] == 2:
                table_name = "B"  # 如果 ERP_number 為 2，插入到資料表 B
            # 將處理後的資料插入到對應的資料表
            insert_data_to_table(row, table_name, conn)

    return valid_data, invalid_data

# 解析和插入 Excel 檔案的資料
def parse_and_insert():
    """
    這個函數負責處理所有的 Excel 檔案，並將資料插入資料庫
    """
    # 遍歷資料夾中的所有 Excel 檔案
    for excel_file_path in excel_files:
        print(f"Processing file: {excel_file_path}")

        # 讀取 Excel 檔案
        df = pd.read_excel(excel_file_path)
        
        # 確保檔案中包含必要的欄位
        required_columns = ['ERP_number', 'ERP_year', 'ERP_date', 'ERP_reference', 'invoice_period', 'seller_tax_id', 'seller_bp_id', 'buyer_tax_id', 'buyer_name']
        # 如果有任何欄位缺失，則跳過該檔案
        if not all(col in df.columns for col in required_columns):
            print(f"Missing required columns in file: {excel_file_path}")
            continue

        # 驗證並處理資料
        valid_data, invalid_data = validate_and_process(df)

        # 如果有無效資料，將它們插入到錯誤資料表中
        if invalid_data:
            for row in invalid_data:
                # 插入無效資料到錯誤資料表
                insert_data_to_table(row[required_columns].tolist(), "error_table", conn)

    print("All data from Excel files have been processed and inserted into the database!")

if __name__ == "__main__":
    # 連接到 SQLite 資料庫
    conn = sqlite3.connect("C:/Users/waylin/mydjango/e_invoice/db.sqlite3")
    # 開始處理檔案並插入資料
    parse_and_insert()
    # 關閉資料庫連接
    conn.close()
